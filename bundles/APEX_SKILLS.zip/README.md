# APEX skill collection

Keep the extracted folders together. Open the [APEX operating guide](AGENTS.md)
and the [coordinator skill](skills/elite-project-orchestrator/SKILL.md).
Choose a specialty from the [skill catalog](config/skills.json), then pair its
SKILL.md with the relevant template and checklist. The
[project types](config/project-types.json) identify the matching files.

For an assistant that accepts text, attach or paste the chosen files and the
[assistant instructions](chatgpt/INSTRUCTIONS.md). For native skill discovery,
copy the chosen skill directory from `skills/` according to your host's
installation instructions, keeping its metadata with it.

Use the [project brief](templates/project-brief.md) and
[final checklist](checklists/final-qa.md) with a sample request: “Use @EPO to
plan a 30-minute lesson on probability and give me an acceptance checklist.”

[Version](VERSION) · [License](LICENSE)
