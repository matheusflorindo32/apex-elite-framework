# APEX scientific toolkit

Start with the [research guide](docs/RESEARCHERS.md), then open the
[coordinator skill](skills/elite-project-orchestrator/SKILL.md) and the
[methodology skill](skills/scientific/SKILL.md) or
[documentary research skill](skills/research/SKILL.md).

For a paper critique, use the [review template](templates/scientific-review.md),
[worked example](examples/scientific-review.md), and
[scientific checklist](checklists/scientific-qa.md).
For a source search, use the [research template](templates/research-project.md),
[worked example](examples/documentary-research.md), and
[research checklist](checklists/research-qa.md).

Attach or paste the chosen files and the
[assistant instructions](chatgpt/INSTRUCTIONS.md) in a text-capable assistant.
Start with an example or research materials you have permission to share.
Verify sources and conclusions yourself before using the result.

The [included catalog](config/skills.json) lists the toolkit's six skills.
Use the separate APEX_SKILLS.zip for other aliases such as @Design.

[Final checklist](checklists/final-qa.md) · [Version](VERSION) · [License](LICENSE)
